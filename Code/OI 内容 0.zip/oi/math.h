/*
 * Powered by ����ˮ��.
 * ÿ��һˮ��ˮˮ��������
*/

#ifndef OI_MATH_H
#define OI_MATH_H

namespace oi
{
    template <typename T> std::vector<T> find_divisor(T n)
    {
        std::vector<T> ans;
        for(T i = 1; i * i <= n; ++ i)
            if(! (n % i))
            {
                ans.push_back(i);
                if(i * i != n)
                    ans.push_back(n / i);
            }
        return ans;
    }

    template <typename T> bool is_prime(T n)
    {
        if(n < 2)
            return false;
        for(T i = 2; i * i <= n; ++ i)
            if(! (n % i))
                return false;
        return true;
    }

    template <typename T> std::map<T, T> prime_factor(T n)
    {
        std::map<T, T> ans;
        if(n < 2)
            return ans;
        for(T i = 2; i * i <= n; ++ i)
            while(! (n % i))
            {
                n /= i;
                ++ ans[i];
            }
        if(n != 1)
            ++ ans[n];
        return ans;
    }

    template <typename T> inline T lcm(const T &n, const T &m)
    {
        return n * m / std::__gcd(n, m);
    }
}

#endif // OI_MATH_H
