/*
 * Powered by ����ˮ��.
 * ÿ��һˮ��ˮˮ��������
*/

#ifndef OI_DP_H
#define OI_DP_H

namespace oi
{
    template <typename T, typename U = std::deque<std::pair<T, unsigned>>, typename
    V = std::less<T>> class MonotoneQueue
    {
    public:
        typedef std::pair<T, unsigned> value_type;
        typedef typename U::size_type size_type;
        MonotoneQueue(): data(std::make_shared<U>(U())){}
        MonotoneQueue(const MonotoneQueue& mq): now(mq.now), max_size(mq.max_size),
    data(mq.data) {}
        MonotoneQueue(const std::initializer_list<T> &il, unsigned ms = 1):
    data(std::make_shared<U>(U())), now(0), max_size(ms)
        {
            build(il.begin(), il.end());
        }
        template <typename W> MonotoneQueue(const W &s, const W &t, unsigned ms = 1):
    data(std::make_shared<U>(U())), now(0), max_size(ms)
        {
            build(s, t);
        }
        MonotoneQueue& operator =(const std::initializer_list<T> &il)
        {
            data -> clear();
            now = 0;
            max_size = 1;
            build(il.begin(), il.end());
        }
        MonotoneQueue& operator =(const MonotoneQueue& mq)
        {
            data = mq.data;
            now = mq.now;
            max_size = mq.max_size();
            return *this;
        }
        ~MonotoneQueue() = default;
        inline bool empty() const
        {
            return data -> empty();
        }
        inline size_type size() const
        {
            return data -> size();
        }
        inline T& front() const
        {
            check(0, "front on empty mq");
            return data -> front().first;
        }
        inline T& back() const
        {
            check(0, "back on empty mq");
            return data -> back().first;
        }
        void push(const T &x)
        {
            while(! empty() && ! V()(back(), x))
                data -> pop_back();
            data -> push_back(std::make_pair(x, ++ now));
            if(now - data -> front().second == max_size)
                data -> pop_front();
        }
    private:
        std::shared_ptr<U> data;
        unsigned now, max_size;
        template <typename W> void build(const W &s, const W &t)
        {
            for(auto i = s; i != t; ++ i)
                push(*i);
        }
        void check(size_type i, const std::string &msg) const
        {
            if(i < 0 || i >= data -> size())
                throw std::out_of_range(msg);
        }
    };

    template <typename T, typename U = std::deque<std::pair<T, unsigned>>, typename
    V = std::less<T>> class MonotoneStack
    {
    public:
        typedef std::pair<T, unsigned> value_type;
        typedef typename U::size_type size_type;
        MonotoneStack(): data(std::make_shared<U>(U())), now(0) {}
        MonotoneStack(const MonotoneStack& ms):
    data(ms.data), now(ms.now) {}
        MonotoneStack(const std::initializer_list<T> &il):
    data(std::make_shared<U>(U())), now(0)
        {
            build(il.begin(), il.end());
        }
        template <typename W> MonotoneStack(const W &s, const W &t):
    data(std::make_shared<U>(U())), now(0)
        {
            build(s, t);
        }
        MonotoneStack& operator =(const std::initializer_list<T> &il)
        {
            data -> clear();
            now = 0;
            build(il.begin(), il.end());
        }
        MonotoneStack& operator =(const MonotoneStack& ms)
        {
            data = ms.data;
            now = ms.now;
            return *this;
        }
        ~MonotoneStack() = default;
        inline bool empty() const
        {
            return data -> empty();
        }
        inline size_type size() const
        {
            return data -> size();
        }
        inline T& bottom() const
        {
            check(0, "bottom on empty ms");
            return data -> front().first;
        }
        inline T& top() const
        {
            check(0, "top on empty ms");
            return data -> back().first;
        }
        std::vector<value_type> push(const T &x)
        {
            std::vector<value_type> ans;
            while(! empty() && V()(x, top()))
            {
                ans.push_back(data -> back());
                data -> pop_back();
            }
            data -> push_back(std::make_pair(x, ++ now));
            return ans;
        }
    private:
        std::shared_ptr<U> data;
        unsigned now;
        template <typename W> void build(const W &s, const W &t)
        {
            for(auto i = s; i != t; ++ i)
                push(*i);
        }
        void check(size_type i, const std::string &msg) const
        {
            if(i < 0 || i >= data -> size())
                throw std::out_of_range(msg);
        }
    };
}

#endif // OI_DP_H
