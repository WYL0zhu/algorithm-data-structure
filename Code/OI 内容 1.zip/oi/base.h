/*
 * Powered by ����ˮ��.
 * ÿ��һˮ��ˮˮ��������
*/

#ifndef OI_BASE_H
#define OI_BASE_H

namespace oi
{
    template <typename T, typename U>
    inline const T &choose(const T &a, const T &b, const U &c)
    {
        return c(a, b) ? a : b;
    }
    template <typename T>
    const T &Log(const size_t &n)
    {
        static std::vector<T> ans{0, 0};
        if(n >= ans.size())
            for(auto i = ans.size(); i != n + 1; ++ i)
                ans.push_back(ans.at(i >> 1) + 1);
        return ans.at(n);
    }
}

#endif // OI_BASE_H
