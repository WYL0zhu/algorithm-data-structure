/*
 * Powered by ����ˮ��.
 * ÿ��һˮ��ˮˮ��������
*/

#ifndef OI_DATA_H
#define OI_DATA_H

#include "oi/base.h"

namespace oi
{
    template <typename T, typename U = std::vector<std::vector<T>>, typename V =
     std::less<T>> class ST
    {
    public:
        typedef T value_type;
        typedef typename U::size_type size_type;
        ST(): data(std::make_shared<U>(U())){}
        ST(const ST& st): data(st.data) {}
        ST(const std::initializer_list<T> &il): data(std::make_shared<U>(U()))
        {
            build(il.begin(), il.end());
        }
        template <typename W> ST(const W &s, const W &t): data(std::make_shared<U>(U()))
        {
            build(s, t);
        }
        ST& operator =(const std::initializer_list<T> &il)
        {
            build(il.begin(), il.end());
        }
        ST& operator =(const ST& st)
        {
            data = st.data;
            return *this;
        }
        ~ST() = default;
        T query(const size_type &l, const size_type &r) const
        {
            check(l, "query out of range of st");
            check(r - 1, "query out of range of st");
            auto k = Log(r - l);
            return choose(data -> at(l).at(k), data -> at(r - (1 << k)).at(k), V());
        }
    private:
        std::shared_ptr<U> data;
        template <typename W> void build(const W &s, const W &t)
        {
            auto n = t - s;
            data -> resize(n);
            for(auto i = data -> begin(), j = 0; i != data -> end();
     ++ i, ++ j)
            {
                i -> resize(Log(n) + 1);
                *i -> begin() = *(s + j);
            }
            for(auto j = 1; j != Log(n) + 1; ++ j)
                for(auto i = data -> begin(); i + (1 << j) != data -> end() + 1;
     ++ i)
                    i -> at(j) = choose(i -> at(j - 1), (i + (1 << j - 1)) ->
    at(j - 1), V());
        }
        void check(size_type i, const std::string &msg) const
        {
            if(i < 0 || i >= data -> size())
                throw std::out_of_range(msg);
        }
    };
}

#endif // OI_DATA_H
